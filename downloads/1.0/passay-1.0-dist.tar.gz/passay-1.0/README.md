## Passay

This project is dual licensed under both the LGPL and Apache 2.
If you have questions or comments about this library send e-mail to
passay@googlegroups.com.

### Building
```sh
git clone git@github.com:vt-middleware/passay.git
cd passay
mvn package
```

### Documentation
See the website: http://www.passay.org
